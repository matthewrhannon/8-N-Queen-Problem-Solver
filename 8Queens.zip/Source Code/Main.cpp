//Written by Matthew Hannon (H564B652)
//4/15/2015

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <time.h>

#include <vector>
#include <set>
#include <tuple>
#include <limits>

/*
      8x8
    XXXXXXXX
    XXXXXXXX
    XXXXXXXX
    XXXXXXXX
    XXXXXXXX
    XXXXXXXX
    XXXXXXXX
    XXXXXXXX
*/
#define DEBUG 0
#define MAX_NUM_ITERATIONS 100000 //100
#define BOARD_SIZE 8 //4//16 //8//4
char start_board[BOARD_SIZE][BOARD_SIZE];
char board[BOARD_SIZE][BOARD_SIZE];
int column_conflicts[BOARD_SIZE];
bool bColumnsTried[BOARD_SIZE];

std::vector<std::vector<std::pair<int, int>>> all_column_conflict_pos;
std::vector<std::pair<int, int>> column_conflict_pos;

std::vector<std::tuple<int, int, int, int>> column_conflicts_history;

#define PI 3.14159265f
#define dot_tolerance 0.1 //Used for floating point rounding
#define dot_validMove 45 //45 degrees

//Start queen position to search from
int start_queen_x = 0;
int start_queen_y = 0;

//Variables to keep track of the current queen position
int curPos_queen_x = start_queen_x;
int curPos_queen_y = start_queen_y;

//Also save old queen position
int oldPos_queen_x = -1;
int oldPos_queen_y = -1;

//Vars to find min
int min_value_found = std::numeric_limits<int>::max();
int min_slot_found = -1;

int old_min_value_found = -1;
int old_min_slot_found = -1;

bool getColumnConflicts();
bool solveBoard();

bool isValidMove(int x_possible, int y_possible, int x_queen, int y_queen) {

    //Make sure we are not moving to our current spot
    if(x_queen == curPos_queen_x && y_queen == curPos_queen_y)
        return false;

    //Queens can move horizontal and diagonal

    if(x_possible == x_queen || y_possible == y_queen) {
        //Then on same row or column

        return true;
    }
   
    //return false;  //Note: horizontal and vertical are coorrect now by exchanging values passed into x_queen and y_queen...

    //What about diagonal?
    //Since it is a square for a board if we take the absolute direction delta between two positions it should be a 45 degree angle?
    //Dot product: a . b = (mag(a)*mag(b))*cos(theta_ab)

    float delta_x = float(x_queen - x_possible);
    float delta_y = float(y_queen - y_possible);
    float mag_delta = (float)sqrt(float(delta_x*delta_x + delta_y*delta_y));
    //delta_x /= mag_delta;
    //delta_y /= mag_delta;

    //float mag_a = (float)sqrt(float(x_possible*x_possible + y_possible*y_possible));
    //x_possible /= mag_a;
    //y_possible /= mag_a;
    float unitVector_X = 1;
    float unitVector_Y = 0;

    float dot_prod = delta_x*unitVector_X + delta_y*unitVector_Y;
    dot_prod /= mag_delta;

    //Calculate magnitude
    //float mag_a = (float)sqrt(float(x_possible*x_possible + y_possible*y_possible));
    //float mag_b = (float)sqrt(float(x_queen*x_queen + y_queen*y_queen));

    //Calculate dot product
    //float dot_prod = float(x_possible*x_queen + y_possible*y_queen);

    //Normalize
    //dot_prod /= mag_a*mag_b;

    //Keep in range? FIXME
    if(dot_prod > 1)
        dot_prod = 1;
    else if(dot_prod < -1)
        dot_prod = -1;
   

    //Sanity check
    if(dot_prod < -1 || dot_prod > 1) {
        printf("ERROR: dot_prod not in range [-1, +1]\n");
        assert(false);
    }

    //Calculate angle
    float dot_angle = abs(float(acos(dot_prod)) * 180.0f / PI);
	printf("dot_angle=%f\n", dot_angle);
    //Check for range test with tolerance
    if( (dot_angle-dot_validMove < dot_tolerance) && (dot_angle-dot_validMove > -dot_tolerance) ) {
        //Within tolerance range so we have a hit
        return true;
    }

    //Test for for 45 degree angle the other direction
    if( (dot_angle-135.0f < dot_tolerance) && (dot_angle-135.0f > -dot_tolerance) ) {
        //Within tolerance range so we have a hit
        return true;
    }


    //Test for if on same axis
    if( (dot_angle-180.0f < dot_tolerance) && (dot_angle-180.0f > -dot_tolerance) ) {
        //Within tolerance range so we have a hit
        return true;
    }

    //Test for orthogonal
    if( (dot_angle-90.0f < dot_tolerance) && (dot_angle-90.0f > -dot_tolerance) ) {
        //Within tolerance range so we have a hit
        return true;
    }


    return false;
}

void print_board() {
    printf("\n");
    for(int x = 0; x < BOARD_SIZE; x++) {
        for(int y = 0; y < BOARD_SIZE; y++) {
            printf("%c ", board[x][y]);
        }

        printf("\n"); //Go to next row
    }
}

void print_start_board() {
	printf("\n");
	for(int x = 0; x < BOARD_SIZE; x++) {
		for(int y = 0; y < BOARD_SIZE; y++) {
			printf("%c ", start_board[x][y]);
		}

		printf("\n"); //Go to next row
	}
}

bool relocateQueen() {

    //We now have functionality to get number of conflicts on each grid unit in the column where we are currently located (current queen)
    //So lets pick the min. conflicts found (or take random if tie) and move our current queen position there,
    //and then try it again until current queen position number of conflicts is the minimum (solved) or max iterations run out (failure)

    //Save old values
    old_min_value_found = min_value_found;
    old_min_slot_found = curPos_queen_y;

    if(!getColumnConflicts())
        assert(false);

    //Pick the min-conflicts found
    bool wasTie = false;
    std::vector<std::pair<bool, int>> conflictTies;
    conflictTies.resize(BOARD_SIZE);

	min_value_found = std::numeric_limits<int>::max();
    for(int x = 0; x < BOARD_SIZE; x++) {
        if(column_conflicts[x] < min_value_found) {
            min_value_found = column_conflicts[x];
            min_slot_found = x;
        } else {
            //Note: curPos_queen_y != x added to keep it from changing to itself
            if(min_value_found == column_conflicts[x] && curPos_queen_y != x) {
                //We have a tie!
                //Mark it and save it
                conflictTies[x].first = true;
                conflictTies[x].second = column_conflicts[x];

                wasTie = true;
                continue;
            }

            //Do defaults
            conflictTies[x].first = false;
            conflictTies[x].second = 0;

        }
    }

////////////////////////////////
//Test if current conflict cost is less than the new found one than do not move
if(min_value_found == column_conflicts[curPos_queen_y]) {
	//Are there other places that we can move with same min_value_found value?
	for(int x = 0; x < BOARD_SIZE; x++) {
		if(column_conflicts[x] == min_value_found && x != curPos_queen_y)
			goto handleTie;
	}

    //printf("NOT MOVING CAUSE CURRENTLY IN BEST SPOT\n\n");
    return true;
}


////////////////////////////////

handleTie:
    //Now check to see if tie
    if(wasTie) {
        int tieCount = 0;
        //Then we have to randomly pick one of them
        for(unsigned int x = 0; x < conflictTies.size(); x++) {
            if(conflictTies[x].first == true && conflictTies[x].second == min_value_found) {
                //Found a tie with the lowest value found
                //First we have to count them
                tieCount++;
            }
        }

        if(tieCount == 0) {
            //No Ties
            //Save our pos. to old pos
            oldPos_queen_x = curPos_queen_x;
            oldPos_queen_y = curPos_queen_y;

            //Now just go to new position
            curPos_queen_x = curPos_queen_x;

            //FIXMEEE!!!!!!!!!!!!!! IS THIS A MISTAKE !!!!!!!!!!!!!!!???????????????????
            curPos_queen_y = min_slot_found; //x should be the new square we want to go to

            //Check if the old position has the minimum value and therefore solved
            /*if(old_min_value_found < min_value_found) {
                printf("SUCCESS??? \n");
                return true;
            }
			*/

            return false;

        }
        //We really should have a tie...
        assert(tieCount >= 0);

        //Pick random number
        int tieBreaker = rand() % tieCount;
        int tieBreakerCounter = 0;

        //Now get info for the new chess square we are moving to
        for(unsigned int x = 0; x < conflictTies.size(); x++) {
            if(conflictTies[x].first == true && conflictTies[x].second == min_value_found) {

                if(tieBreaker == tieBreakerCounter) {
                    //We have found our new pad

                    //Save our pos. to old pos
                    oldPos_queen_x = curPos_queen_x;
                    oldPos_queen_y = curPos_queen_y;

                    //Now just go to new position
                    curPos_queen_x = curPos_queen_x;

                    //FIXMEEE!!!!!!!!!!!!!! IS THIS A MISTAKE !!!!!!!!!!!!!!!???????????????????
                    curPos_queen_y = x; //x should be the new square we want to go to

                    break;
                }

                tieBreakerCounter++;
            }
        }
       
       

    } else {
        //Save our pos. to old pos
        oldPos_queen_x = curPos_queen_x;
        oldPos_queen_y = curPos_queen_y;

        //Now just go to new position
        curPos_queen_x = curPos_queen_x;

        //FIXMEEE!!!!!!!!!!!!!! IS THIS A MISTAKE !!!!!!!!!!!!!!!???????????????????
        curPos_queen_y = min_slot_found; //min_slot_found should be the new square we want to go to
    }

    //Check if the old position has the minimum value and therefore solved
    /*if(old_min_value_found < min_value_found) {
        printf("SUCCESS??? \n");
        return true;
    }
	*/
    return false;
}


bool getColumnConflicts() {
    //Reset vars
    for(int x = 0; x < BOARD_SIZE; x++) {
        column_conflicts[x] = 0;
    }

    all_column_conflict_pos.clear();
    column_conflict_pos.clear();
    column_conflicts_history.clear();

    //Create room for the conflicts in each square
    all_column_conflict_pos.clear();
    all_column_conflict_pos.resize(BOARD_SIZE);

    //Now find conflicts for each column
    for(int possible_moves_in_Col = 0; possible_moves_in_Col < BOARD_SIZE; possible_moves_in_Col++) {
        //Search for each slot in the current column
        column_conflict_pos.clear();

		if(DEBUG)
			printf("\n\n%d)", possible_moves_in_Col);

        for(int x = 0; x < BOARD_SIZE; x++) {

            for(int y = 0; y < BOARD_SIZE; y++) {
                //if(curPos_queen_x == x && curPos_queen_y == y)
                //    continue;

                //First check if this slot does contain a queen and make sure we aren't attacking ourselves
                if(board[x][y] == 'X' && (x != curPos_queen_x || y != curPos_queen_y)) {

                    //Slot is contains queens so calculate if we can attack it from our position at [start_queen_x, start_queen_y]
                    if(isValidMove(curPos_queen_x, possible_moves_in_Col, y, x)) {
                        //Save the positions of queen attacks
                        column_conflict_pos.push_back(std::make_pair(y, x));

                        //We can be attacked and vice-versa so add 1
                        column_conflicts[possible_moves_in_Col]++;
						if(DEBUG)
							printf("\n\t Conflict found at x=%d y=%d and curPos_queen_x=%d possible_moves_in_Col=%d", y, x, curPos_queen_x, possible_moves_in_Col);
                    }


                }

            }
        }

        //Save these conflicts
        all_column_conflict_pos[possible_moves_in_Col] = column_conflict_pos;
    }

	//Note: this code was written originally because I didn't think that counting 2 queens attacking on same diagonal should be counted as 2 but only as 1 conflict per the wiki page on 8queens...
	/*
    //Now need to check if any of the queen conflicts we found share a row or diagonal and if so subtract the extras from its queen attack counter
    for(int x = 0; x < all_column_conflict_pos.size(); x++) {
        for(int a = 0; a < all_column_conflict_pos[x].size(); a++) {
            //Set up for vars
            int x_queen = all_column_conflict_pos[x][a].first;
            int y_queen = all_column_conflict_pos[x][a].second;

            for(int b = 0; b < all_column_conflict_pos[x].size(); b++) {
                //Need this extra loop because have to compare each entry to every other entry
                int x_queen1 = all_column_conflict_pos[x][b].first;
                int y_queen1 = all_column_conflict_pos[x][b].second;

                //First check if they share a row or column
                if(x_queen == x_queen1 || y_queen == y_queen1) {
                    //Not good

                    //Check if this one has already been processed
                    bool breakOut = false;
                    for(int i = 0; i < column_conflicts_history.size(); i++) {
                        if(std::get<0>(column_conflicts_history[i]) == std::get<2>(column_conflicts_history[i]) && std::get<1>(column_conflicts_history[i]) == std::get<3>(column_conflicts_history[i])) {
                            //We already processed this
                            breakOut = true;
                            break;
                        }
                    }

                    if(breakOut)
                        continue;

                    //Decrease count of conflicts
                    column_conflicts[x]--;

                    if(column_conflicts[x] < 0) {
                        column_conflicts[x] = 0;
                        //assert(false);
                    }

                    //Save conflicts so we don't decrease values more than once
                    column_conflicts_history.push_back(std::make_tuple(x_queen, y_queen, x_queen1, y_queen1));
                } else {
                    //Check if they are diagonal
                    //FIXME: terrible code resuse here

                    float delta_x = float(x_queen - x_queen1);
                    float delta_y = float(y_queen - y_queen1);
                    float mag_delta = (float)sqrt(float(delta_x*delta_x + delta_y*delta_y));

                    float unitVector_X = 1;
                    float unitVector_Y = 0;

                    float dot_prod = delta_x*unitVector_X + delta_y*unitVector_Y;
                    dot_prod /= mag_delta;

                    //Keep in range? FIXME
                    if(dot_prod > 1)
                        dot_prod = 1;
                    else if(dot_prod < -1)
                        dot_prod = -1;

                    //Sanity check
                    if(dot_prod < -1 || dot_prod > 1) {
                        printf("ERROR: dot_prod not in range [-1, +1]\n");
                        assert(false);
                    }

                    //Calculate angle
                    float dot_angle = abs(float(acos(dot_prod)) * 180.0f / PI);

                    //Check for range test with tolerance
                    if( (dot_angle-dot_validMove < dot_tolerance) && (dot_angle-dot_validMove > -dot_tolerance) ) {
                        //Within tolerance range so we have a hit

                        //Check if this one has already been processed
                        bool breakOut = false;
                        for(int i = 0; i < column_conflicts_history.size(); i++) {
                            if(std::get<0>(column_conflicts_history[i]) == std::get<2>(column_conflicts_history[i]) && std::get<1>(column_conflicts_history[i]) == std::get<3>(column_conflicts_history[i])) {
                                //We already processed this
                                breakOut = true;
                                break;
                            }
                        }

                        if(breakOut)
                            continue;

                        //Decrease count of conflicts
                        column_conflicts[x]--;

                        if(column_conflicts[x] < 0) {
                            column_conflicts[x] = 0;
                            //assert(false);
                        }

                        //Save conflicts so we don't decrease values more than once
                        column_conflicts_history.push_back(std::make_tuple(x_queen, y_queen, x_queen1, y_queen1));
                    }

                    //Test for for 45 degree angle the other direction
                    if( (dot_angle-135.0f < dot_tolerance) && (dot_angle-135.0f > -dot_tolerance) ) {
                        //Within tolerance range so we have a hit

                        //Check if this one has already been processed
                        bool breakOut = false;
                        for(int i = 0; i < column_conflicts_history.size(); i++) {
                            if(std::get<0>(column_conflicts_history[i]) == std::get<2>(column_conflicts_history[i]) && std::get<1>(column_conflicts_history[i]) == std::get<3>(column_conflicts_history[i])) {
                                //We already processed this
                                breakOut = true;
                                break;
                            }
                        }

                        if(breakOut)
                            continue;

                        //Decrease count of conflicts
                        column_conflicts[x]--;

                        if(column_conflicts[x] < 0) {
                            column_conflicts[x] = 0;
                            //assert(false);
                        }

                        //Save conflicts so we don't decrease values more than once
                        column_conflicts_history.push_back(std::make_tuple(x_queen, y_queen, x_queen1, y_queen1));
                    }
                }
            }
        }



    }
	*/

    //Print sanitized conflicts
/*
    for(unsigned int x = 0; x < all_column_conflict_pos.size(); x++)  {
        printf("\nSquare %d:\n", x);

        for(unsigned int y = 0; y < all_column_conflict_pos[x].size(); y++) {
            printf("\t%d,%d\n", all_column_conflict_pos[x][y].first, all_column_conflict_pos[x][y].second);
        }
    }
*/


    //Print current conflicts

    //Offset drawn conflict data to proper column
/*
    for(int offset = 0; offset < curPos_queen_y; offset++) {
        printf(" ");
    }

    for(int i = 0; i < BOARD_SIZE; i++) {
        printf("%d\n", column_conflicts[i]);
    }
*/

    return true;
}

bool solveBoard() {
	bool firstTimeInFunction = true;
    bool boardSolved = false;
    int max_iterations = MAX_NUM_ITERATIONS;

    while(!boardSolved) {
		if(firstTimeInFunction) {
			//printf("First time in solveBoard function...\n");
			//firstTimeInFunction = false;
			goto pickColumn;
		}


        if(max_iterations-- <= 0) {
            printf("ERROR: exceeded max iterations!\n");
            return false;
        }


		if(!relocateQueen()) {

			//printf("relocateQueen returned a false value\n");

			//See if we even need to change this piece  //DELETEM E!!??
			//if(column_conflicts[oldPos_queen_y] == 0)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			//    goto change;

			//Update board
			//board[curPos_queen_y][curPos_queen_x] =
			//Only do switch if we found new place to go
			if(curPos_queen_y != oldPos_queen_y) { //) && curPos_queen_x != oldPos_queen_x) {
				board[curPos_queen_y][curPos_queen_x] = 'X';
				board[oldPos_queen_y][oldPos_queen_x] = 'O';
			}

			//Save old vars
			oldPos_queen_x = curPos_queen_x;
			oldPos_queen_y = curPos_queen_y;

		}


        //Now randomly select next x column to do this to
//change:

        //while(curPos_queen_x == oldPos_queen_x)    //FIXME: ??? added on! Choose a different row!

pickColumn:
		//Now randomly select a new column to move queen on but don't pick column that has a current queen with no conflicts as well as lowest value in column
		bool foundCandidate = false; 

		//Need to keep track of which columns we have tried to find a candidate on so we know if we have found a solution or not and don't continuously loop
		for(int x = 0; x < BOARD_SIZE; x++) 
			bColumnsTried[x] = false;

		while(!foundCandidate && !boardSolved) {
			curPos_queen_x = rand() % BOARD_SIZE;

			for(int tmp = 0; tmp < BOARD_SIZE; tmp++) {
				if(board[tmp][curPos_queen_x] == 'X') {
					//Get x and y position for start queen to search from
					curPos_queen_y = tmp;
					break;
				}
			}

			//CHEAP FIX
			int tmp_oldPos_queen_x = curPos_queen_x;
			int tmp_oldPos_queen_y = curPos_queen_y;

			relocateQueen(); //Note: now column_conflicts array should be filled in with conflict data

			curPos_queen_x = tmp_oldPos_queen_x;
			curPos_queen_y = tmp_oldPos_queen_y;

			//Test if we want to pick this column
			if(column_conflicts[curPos_queen_y] == 0) {
				//Now need to test that no other zeros exist in conflicts array
				int zeroCounter = 0;
				for(int x = 0; x < BOARD_SIZE; x++) {
					if(column_conflicts[x] == 0) 
						zeroCounter++;
				}

				if(zeroCounter != 1) {
					if(DEBUG)
						printf("Note: This column has more than 1 zero for queen to move to.\n");

					foundCandidate = true;
					break;
				}

			} else {
				foundCandidate = true;
				break;
			}

			//This column looks good with no conflicts on its queen
			if(!foundCandidate) {
				assert(curPos_queen_x <= BOARD_SIZE);
				bColumnsTried[curPos_queen_x] = true;
			}

			//Now test if found solution
			bool bSuccess = true;
			for(int x = 0; x < BOARD_SIZE; x++) {
				assert(x <= BOARD_SIZE);
				if(bColumnsTried[x] != true) {
					bSuccess = false;
					break;
				}
			}

			if(bSuccess) {
				//We found solution!?
				boardSolved = true;
			}
		}
		
		if(firstTimeInFunction) {
			oldPos_queen_x = -1;
			oldPos_queen_y = -1;
			firstTimeInFunction = false;
		}
			
		//if(DEBUG)
			printf("Chosen queen coord: x = %d y = %d\n", curPos_queen_x, curPos_queen_y);
       
		print_board();
    }

	printf("\n\nSolved! iterations_to_solve=%d\n\n", MAX_NUM_ITERATIONS - max_iterations);
	printf("Starting board:");
	print_start_board();
	printf("Solved board:");
	print_board();
	printf("\n\nSolved! iterations_to_solve=%d\n\n", MAX_NUM_ITERATIONS - max_iterations);

    return true;
}


int main() {
    srand(time(NULL));
redo:
    printf("\n\nN-Queens Problem - written by Matthew Hannon (H564B652)\n");

    //Lets make a board with no queens
    for(int x = 0; x < BOARD_SIZE; x++) {
        for(int y = 0; y < BOARD_SIZE; y++) {
            board[x][y] = 'O';
			start_board[x][y] = 'O';
        }
    }

    //Set conflicts initial to 0
    for(int x = 0; x < BOARD_SIZE; x++)
        column_conflicts[x] = 0;

	printf("Starting board:\n");
	print_board();
   
    //Now lets put 8 queens randomly on board
    /*for(int y = 0; y < BOARD_SIZE; y++) {
        //Loop through columns
        int tmp_pos = rand() % BOARD_SIZE;
        for(int x = 0; x < BOARD_SIZE; x++) {
            if(x == tmp_pos) {
                board[x][y] = 'X';
				start_board[x][y] = 'X';
            }
        }
    }
	*/

    
	//Get user to set specific pattern for queens
	//#define BOARD_SIZE 4//16 //8//4

	int input = -1;
	printf("\nBoard is %d / %d. Please enter where you want to place a queen on each row by entering the number for the column you want the \'X\'\n", BOARD_SIZE, BOARD_SIZE);
	for(int y = 0; y < BOARD_SIZE; y++) {
		printf("Please enter which column number you want to place the queen for row %d) ", y);
		scanf("%d", &input);

		if(input >= BOARD_SIZE) {
			printf("Invalid entry! Relaunching program...");
			goto redo;
		}

		board[input][y] = 'X';
		start_board[input][y] = 'X';

		print_board();
	}

	printf("Would you like to reenter your queen specifications? Enter Y or N) ");
	char tmp;
	scanf("%c", &tmp);
	if(strupr(&tmp) == "Y" && strupr(&tmp) != "N") {
		printf("Relaunching application...\n");
		goto redo;
	} else if(strupr(&tmp) == "N") {
		printf("Attempting to solve board...\n");
	}

	/*
	board[0][1] = 'X'; 
	board[0][3] = 'X';
	//board[1][3] = 'X';

	board[2][0] = 'X';
	board[3][2] = 'X';
	*/
	printf("Starting board:\n");
    print_board();

	/*
    //Start by randomly selecting a queen in a column
    int start_queen_in_Col = rand() % BOARD_SIZE;

    for(int tmp = 0; tmp < BOARD_SIZE; tmp++) {
        if(board[tmp][start_queen_in_Col] == 'X') {
            //Get x and y position for start queen to search from
            start_queen_x = start_queen_in_Col;
            start_queen_y = tmp;
            break;
        }
    }

    printf("start_queen_x=%d start_queen_y=%d\n", start_queen_x, start_queen_y);

    
       // Note that the number of conflicts is generated by each new direction that a queen can attack from. If two queens would attack from the same direction (row, or diagonal) then the conflict is only counted once.
       // Also note that if a queen is  in a position in which a move would put it in greater conflict than its current position,
       // it does not make a move. It follows that if a queen is in a state of minimum conflict, it does not have to move.
       
    

    curPos_queen_x = start_queen_x;
    curPos_queen_y = start_queen_y;
   */

    if(!solveBoard()) {
        printf("FAILURE\n");
    } else {
        printf("YEAH!\n");
    }
   


    return 1;
}